import sqlite3
import os

os.remove('chessdb.sqlite')

conn = sqlite3.connect('chessdb.sqlite')
cur = conn.cursor()

creating_query = open('creating_db.sql', 'r')

cur.executescript(creating_query.read())