from PyQt5 import uic
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel, QWidget, QLineEdit
from PyQt5.QtGui import QPixmap, QDrag
from PyQt5 import QtGui
from PyQt5 import QtCore
import sqlite3
from main import MainWindow

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.ui = uic.loadUi('login.ui', self)
        self.ui.le_password.setEchoMode(QLineEdit.Password)
        self.ui.button_login.clicked.connect(self.login)
        self.ui.button_user.clicked.connect(self.user)
        self.show()

    def user(self):
        window = MainWindow(False)
        window.setWindowTitle('Шахматные игры')
        self.close()

    def login(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('SELECT * from admins WHERE login = ?', (self.ui.le_login.text(), ))
        admin = cur.fetchall()
        if admin:
            if admin[0][2] == self.ui.le_password.text():
                window = MainWindow(True)
                window.setWindowTitle('Шахматные игры')
                self.close()
        else:
            pass

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = LoginWindow()
    window.setWindowTitle('Шахматные игры')
    sys.exit(app.exec_())