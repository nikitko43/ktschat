PRAGMA foreign_keys = on;

CREATE TABLE organizer (
	id INTEGER PRIMARY KEY,
	name TEXT NOT NULL
);

CREATE TABLE place (
	id INTEGER PRIMARY KEY,
	adress TEXT NOT NULL,
	country TEXT,
	city TEXT
);

CREATE TABLE tournament (
	id INTEGER PRIMARY KEY,
	name TEXT NOT NULL,
	type TEXT,
	beginning_time TEXT,
	ending_time TEXT,
	organizer_id INTEGER,
	place_id INTEGER,
	FOREIGN KEY (organizer_id) REFERENCES organizer(id),
	FOREIGN KEY (place_id) REFERENCES place(id)
);

CREATE TABLE team (
	id INTEGER PRIMARY KEY,
	name TEXT NOT NULL,
	country TEXT,
	city TEXT,
	organization TEXT
);

CREATE TABLE player (
	id INTEGER PRIMARY KEY,
	name TEXT NOT NULL,
	surname TEXT NOT NULL,
	rating INTEGER,
	achievements TEXT,
	team_id INTEGER,
	FOREIGN KEY (team_id) REFERENCES team(id)
);

CREATE TABLE game (
	id INTEGER PRIMARY KEY,
	type TEXT,
	stage_of_tournament TEXT,
	description TEXT,
	tournament_id INTEGER,
	white_player_id INTEGER NOT NULL,
	black_player_id INTEGER NOT NULL,
	winner_id INTEGER,
	FOREIGN KEY (black_player_id) REFERENCES player(id),
	FOREIGN KEY (white_player_id) REFERENCES player(id),
	FOREIGN KEY (winner_id) REFERENCES player(id),
	FOREIGN KEY (tournament_id) REFERENCES tournament(id)
);

CREATE TABLE move (
	id INTEGER PRIMARY KEY,
	order_number INTEGER NOT NULL,
	white_move TEXT NOT NULL,
	black_move TEXT,
	game_end TEXT,
	game_id INTEGER NOT NULL,
	FOREIGN KEY (game_id) REFERENCES game(id)
);

CREATE TABLE admins (
	id INTEGER PRIMARY KEY,
	login TEXT NOT NULL,
	password TEXT NOT NULL
);

INSERT INTO tournament (id, name) VALUES
(1, 'Чемпионат мира'),
(2, 'Так по мелочи');

INSERT INTO team (id, name, country) VALUES
(1, 'Лучшие', 'Москва'),
(2, 'Худшие', 'Нелидово');

INSERT INTO player (id, name, surname, rating, achievements, team_id) VALUES 
(1, 'Никита', 'Реутов', '999', 'Гроссмейстер', 1),
(2, 'Дроп', 'Басевич', '111', 'Никто', 2);

INSERT INTO game (white_player_id, black_player_id, winner_id, tournament_id) VALUES
(1, 2, 1, 1);

INSERT INTO admins (login, password) VALUES
('Магнус', 'e4e5'),
('Реутов Никита', '0000')

