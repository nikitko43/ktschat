from cx_Freeze import setup, Executable

base = None    

executables = [Executable("login.py", base=base)]

packages = ["idna"]
options = {
    'build_exe': {    
        'packages':packages,
    },    
}

setup(
    name = "Шахматные игры",
    options = options,
    version = "2.0",
    description = 'Шахматные игры',
    executables = executables
)