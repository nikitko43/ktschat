import sqlite3
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QLabel, QTableWidgetItem, QAbstractItemView, QDateEdit
from PyQt5.QtWidgets import QComboBox, QLineEdit, QPushButton
from PyQt5.QtGui import QPixmap, QIntValidator
from PyQt5 import uic
from functools import partial
from board import ChessGameWindow
from PyQt5.QtCore import QDate
import sip

def get_data(table):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    if table == 'game':
        cur.execute('''
            SELECT g.id, t.name, g.type, g.stage_of_tournament,
            (p1.name || " " || p1.surname) AS p1_name, 
            (p2.name || " " || p2.surname) AS p2_name,
            (w.name || " " || w.surname) AS w_name,
            g.description
            FROM game AS g
            LEFT JOIN tournament AS t on g.tournament_id = t.id
            LEFT JOIN player AS p1 on p1.id = g.white_player_id
            LEFT JOIN player AS p2 on p2.id = g.black_player_id
            LEFT JOIN player AS w on w.id = g.winner_id
            ''')

        names = ['ID','Турнир', 'Тип игры', 'Этап турнира', 'Игрок белыми', 'Игрок черными',
                 'Победитель', 'Описание']

    if table == 'player':
        cur.execute('''
            SELECT p.id, p.surname, p.name, p.rating, p.achievements, t.name
            FROM player AS p
            LEFT JOIN team AS t on p.team_id = t.id
                    ''')

        names = ['ID', 'Фамилия', 'Имя', 'Рейтинг', 'Достижения', 'Команда']

    if table == 'tournament':
        cur.execute('''
            SELECT t.id, t.name, t.type, t.beginning_time, t.ending_time, o.name, p.adress
            FROM tournament AS t
            LEFT JOIN organizer AS o on t.organizer_id = o.id
            LEFT JOIN place AS p on t.place_id = p.id
            ''')

        names = ['ID', 'Название', 'Тип', 'Время начала', 'Время окончания', 'Организатор', 'Адрес проведения']

    if table == 'organizer':
        cur.execute('SELECT * FROM organizer')
        names = ['ID', 'Имя']

    if table == 'place':
        cur.execute('SELECT * FROM place')
        names = ['ID', 'Адрес', 'Страна', 'Город']

    if table == 'team':
        cur.execute('SELECT * FROM team')
        names = ['ID', 'Название', 'Страна', 'Город', 'Организация']

    if table == 'stats':
        cur.execute('''SELECT (p.name || " " || p.surname) AS p_name, 
            p.achievements, p.rating, t.name, COUNT(g.winner_id) FROM player AS p
            JOIN game AS g ON p.id = g.winner_id
            LEFT JOIN team AS t on p.team_id = t.id
            GROUP BY p.id
            ''')
        names = ['Имя', 'Достижения', 'Рейтинг', 'Команда', 'Количество побед']


    return (cur.fetchall(), names)

def get_game_item(item_id):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('''
        SELECT t.name, g.type, g.stage_of_tournament, g.description,
        p1.name, p1.surname, p2.name, p2.surname, w.name, w.surname,
        g.description
        FROM game AS g
        LEFT JOIN tournament AS t on g.tournament_id = t.id
        LEFT JOIN player AS p1 on p1.id = g.white_player_id
        LEFT JOIN player AS p2 on p2.id = g.black_player_id
        LEFT JOIN player AS w on w.id = g.winner_id
        WHERE g.id = {}
        '''.format(item_id))

    item = cur.fetchone()
    return {'t_name': item[0], 'g_type': item[1], 'g_stage': item[2], 
            'g_descr': item[3], 'p1_name': item[4], 'p1_surname': item[5],
            'p2_name': item[6], 'p2_surname': item[7], 'w_name': item[8], 
            'w_surname': item[9], 'descr': item[10]}

def get_tournament_item(item_id):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('''
        SELECT t.id, t.name, t.type, t.beginning_time, t.ending_time, o.name, p.adress
        FROM tournament AS t
        LEFT JOIN organizer AS o on t.organizer_id = o.id
        LEFT JOIN place AS p on t.place_id = p.id
        WHERE t.id = {}
        '''.format(item_id))

    item = cur.fetchone()
    return {'id': item[0], 'name': item[1], 'type': item[2], 'b_time': item[3],
            'e_time': item[4], 'organizer': item[5], 'adress': item[6]}


def get_player_item(item_id):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('''
        SELECT p.surname, p.name, p.rating, p.achievements, t.name
        FROM player AS p
        LEFT JOIN team AS t on p.team_id = t.id
        WHERE p.id = {}
        '''.format(item_id))

    item = cur.fetchone()
    return {'surname': item[0], 'name': item[1], 'rating': item[2], 
            'achievements': item[3], 't_name': item[4]}

def get_organizer(item_id):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('SELECT * FROM organizer where id = {}'.format(item_id))

    item = cur.fetchone()
    return {'id': item[0], 'name': item[1]}

def get_places():
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('SELECT adress FROM place')
    return [i[0] for i in cur.fetchall()]

def get_tournaments_names():
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('SELECT name FROM tournament')
    return [i[0] for i in cur.fetchall()]

def get_organizators():
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('SELECT name FROM organizer')
    return [i[0] for i in cur.fetchall()]

def get_all_players():
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('SELECT name, surname FROM player')
    return [i[1] + ' ' + i[0] for i in cur.fetchall()]

def change_one(table, _id, column, set_value):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute("UPDATE {} SET {} = '{}' WHERE id = {}".format(table, column, set_value, _id))
    conn.commit()

def find_one_by_id(table, column, _id):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute('SELECT {} FROM {} WHERE id = {}'.format(column, table, _id))
    return cur.fetchone()[0]

def find_id_by_one(table, column, value):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute("SELECT id FROM {} WHERE {} = '{}'".format(table, column, value))
    return cur.fetchone()[0]

def delete_one(table, _id):
    conn = sqlite3.connect('chessdb.sqlite')
    cur = conn.cursor()

    cur.execute("DELETE FROM {} WHERE id = {}".format(table, _id))
    if table == 'game':
        cur.execute("DELETE FROM move WHERE game_id = {}".format(_id))

    conn.commit()

class EditLayout(QWidget):
    def __init__(self, parent, table, choosed_id, admin = False):
        super().__init__(parent)
        self.admin = admin
        self.parent = parent
        self.table = table
        self.id = choosed_id

        self.line_edit_size = (350, 20)
        self.combo_box_size = (350, 30)
        self.label_size = (300, 20)
        self.line_edit_indent = 30
        self.combo_box_indent = 40
        self.label_indent = 20
        self.button_size = (350, 20)
        self.button_indent = 20

        self.move(230, 10)
        self.setUi()

    def newLabel(self, text):
        l = QLabel(self)
        l.setText(text)
        return l

    def newComboBox(self, value, values, f):
        cb = QComboBox(self)
        cb.addItems(values)
        if not self.admin:
            cb.setEnabled(False)
        if len(values) == 0 or not value:
            cb.setCurrentIndex(0)
        elif value not in values:
            cb.setCurrentIndex(0)
        else:
            cb.setCurrentIndex(values.index(value))
        f = partial(f, cb = cb)
        cb.currentIndexChanged.connect(f)
        return cb

    def newLineEdit(self, text, f, only_numbers = False):
        et = QLineEdit(self)
        et.setText(text)
        f = partial(f, le = et)
        if not self.admin:
            et.setReadOnly(True)
        if only_numbers:
            onlyInt = QIntValidator()
            et.setValidator(onlyInt)
        et.editingFinished.connect(f)
        return et

    def newButton(self, text, pos, size, f):
        but = QPushButton(self)
        but.move(*pos)
        but.resize(*size)
        but.setText(text)
        but.setFlat(False)
        but.clicked.connect(f)
        return but

    def newDateEdit(self, date, f):
        de = QDateEdit(self)
        if not self.admin:
            de.setReadOnly(True)
        if not date:
            date = QDate(2018, 4, 25)
        de.setDate(date)
        f = partial(f, de = de)
        de.dateChanged.connect(f)
        return de

    def place(self):
        x = 0
        y = 0
        for item in self.items:
            item.move(x, y)
            if type(item) == QLabel:
                item.resize(*self.label_size)
                y += self.label_indent

            if type(item) == QLineEdit:
                item.resize(*self.line_edit_size)
                y += self.line_edit_indent

            if type(item) == QComboBox:
                item.resize(*self.combo_box_size)
                y += self.combo_box_indent

            if type(item) == QDateEdit:
                item.resize(*self.line_edit_size)
                y += self.line_edit_indent

            if type(item) == QPushButton:
                item.resize(*self.button_size)
                y += self.button_indent

class EditLayoutTournament(EditLayout):
    def setUi(self):
        self.items = []

        item = get_tournament_item(self.id)

        self.items.append(self.newLabel('Название:'))

        def name_changed(le):
            change_one('tournament', self.id, 'name', le.text())

        self.items.append(self.newLineEdit(item['name'], name_changed))
        self.items.append(self.newLabel('Тип турнира:'))

        def type_changed(le):
            change_one('tournament', self.id, 'type', le.text())

        self.items.append(self.newLineEdit(item['type'], type_changed))
        self.items.append(self.newLabel('Время начала:'))

        def beginning_changed(de):
            d = de.date()
            change_one('tournament', self.id, 'beginning_time', '.'.join((str(d.day()), str(d.month()), str(d.year()))))

        if item['b_time']:
            d, m, y = item['b_time'].split('.')
            date = QDate(int(y), int(m), int(d))
        else:
            date = None
        self.items.append(self.newDateEdit(date, beginning_changed))

        self.items.append(self.newLabel('Время окончания:'))

        def ending_changed(de):
            d = de.date()
            change_one('tournament', self.id, 'ending_time', '.'.join((str(d.day()), str(d.month()), str(d.year()))))

        if item['e_time']:
            d, m, y = item['e_time'].split('.')
            date = QDate(int(y), int(m), int(d))
        else:
            date = None
        self.items.append(self.newDateEdit(date, ending_changed))

        def organizer_changed(index, cb):
            if cb.currentText() == '' or cb.currentText() == ' ':
                change_one('tournament', self.id, 'organizer_id', None)
            else:
                change_one('tournament', self.id, 'organizer_id', 
                    find_id_by_one('organizer', 'name', cb.currentText()))

        self.items.append(self.newLabel('Организатор:'))

        if not item['organizer']:
            self.items.append(self.newComboBox('', [''] + get_organizators(), organizer_changed))
        else:
            self.items.append(self.newComboBox(item['organizer'], get_organizators() + [' '], organizer_changed))
        self.items.append(self.newLabel('Место проведения:'))

        def place_changed(index, cb):
            if cb.currentText() == '':
                change_one('tournament', self.id, 'place', None)
            else:
                change_one('tournament', self.id, 'place_id', 
                    find_id_by_one('place', 'adress', cb.currentText()))
            
        self.items.append(self.newComboBox(item['organizer'], get_places(), place_changed))

        def delete_tournament():
            delete_one('tournament', self.id)
            self.parent.choose_layout('layout_tournaments')
            self.parent.ui.table_tournament.clearSelection()

        if self.admin:
            self.items.append(self.newButton('Удалить турнир', (10,10), (10,10), delete_tournament))

        self.place()

class EditLayoutPlace(EditLayout):
    def setUi(self):
        self.items = []
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('SELECT * FROM place where id = {}'.format(self.id))

        item = cur.fetchone()
        item = {'id': item[0], 'adress': item[1], 'country': item[2], 'city': item[3]}

        self.items.append(self.newLabel('Адрес: '))

        def adress_changed(le):
            change_one('place', self.id, 'adress', le.text())

        self.items.append(self.newLineEdit(item['adress'], adress_changed))
        self.items.append(self.newLabel('Страна: '))

        def country_changed(le):
            change_one('place', self.id, 'country', le.text())

        self.items.append(self.newLineEdit(item['country'], country_changed))
        self.items.append(self.newLabel('Город: '))

        def city_changed(le):
            change_one('place', self.id, 'city', le.text())

        self.items.append(self.newLineEdit(item['city'], city_changed))

        def delete_place():
            delete_one('place', self.id)
            self.parent.choose_layout('layout_places')
            self.parent.ui.table_place.clearSelection()

        if self.admin:
            self.items.append(self.newButton('Удалить место проведения', (10,10), (10,10), delete_place))

        self.place()

class EditLayoutTeam(EditLayout):
    def setUi(self):
        self.items = []
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('SELECT * FROM team where id = {}'.format(self.id))

        item = cur.fetchone()
        item = {'id': item[0], 'name': item[1], 'country': item[2], 'city': item[3], 'organization': item[4]}

        self.items.append(self.newLabel('Название: '))

        def name_changed(le):
            change_one('team', self.id, 'name', le.text())

        self.items.append(self.newLineEdit(item['name'], name_changed))
        self.items.append(self.newLabel('Страна: '))

        def country_changed(le):
            change_one('team', self.id, 'country', le.text())

        self.items.append(self.newLineEdit(item['country'], country_changed))
        self.items.append(self.newLabel('Город: '))

        def city_changed(le):
            change_one('team', self.id, 'city', le.text())

        self.items.append(self.newLineEdit(item['city'], city_changed))
        self.items.append(self.newLabel('Организация: '))

        def organization_changed(le):
            change_one('team', self.id, 'organization', le.text())

        self.items.append(self.newLineEdit(item['organization'], organization_changed))

        def delete_place():
            delete_one('team', self.id)
            self.parent.choose_layout('layout_teams')
            self.parent.ui.table_place.clearSelection()

        if self.admin:
            self.items.append(self.newButton('Удалить команду', (10,10), (10,10), delete_place))

        self.place()

class EditLayoutGame(EditLayout):
    def setUi(self):
        self.items = []

        item = get_game_item(self.id)
        self.items.append(self.newLabel('Турнир: '))

        def index_tournament_changed(index, cb):
            change_one('game', self.id, 'tournament_id', 
                find_id_by_one('tournament', 'name', cb.currentText()))

        self.items.append(self.newComboBox(item['t_name'], get_tournaments_names(), index_tournament_changed))
        self.items.append(self.newLabel('Тип игры:'))

        def type_game_changed(le):
            change_one('game', self.id, 'type', le.text())

        self.items.append(self.newLineEdit(item['g_type'], type_game_changed))
        self.items.append(self.newLabel('Этап турнира:'))

        def stage_changed(le):
            change_one('game', self.id, 'stage_of_tournament', le.text())

        self.items.append(self.newLineEdit(item['g_stage'], stage_changed))

        if not item['p1_surname'] or not item['p2_surname']:
            players = ['', '']
        else:
            players = [item['p1_surname'] + ' ' + item['p1_name'], item['p2_surname'] + ' ' + item['p2_name']]

        self.items.append(self.newLabel('Игрок белыми:'))
        
        def w_player_changed(index, cb):
            conn = sqlite3.connect('chessdb.sqlite')
            cur = conn.cursor()
            surname, name = cb.currentText().split(' ', 1)
            cur.execute("SELECT id FROM player WHERE surname = '{}' AND name = '{}'".format(surname, name))
            ind = cur.fetchone()[0]
            cur.execute("UPDATE {} SET {} = '{}' WHERE id = {}".format('game', 'white_player_id', ind, self.id))
            conn.commit()

        self.items.append(self.newComboBox(players[0], get_all_players(), w_player_changed))
        self.items.append(self.newLabel('Игрок черными:'))

        def b_player_changed(index, cb):
            conn = sqlite3.connect('chessdb.sqlite')
            cur = conn.cursor()
            surname, name = cb.currentText().split(' ', 1)
            cur.execute("SELECT id FROM player WHERE surname = '{}' AND name = '{}'".format(surname, name))
            ind = cur.fetchone()[0]
            cur.execute("UPDATE {} SET {} = '{}' WHERE id = {}".format('game', 'black_player_id', ind, self.id))
            conn.commit()

        self.items.append(self.newComboBox(players[1], get_all_players(), b_player_changed))
        self.items.append(self.newLabel('Победитель:'))

        def winner_changed(index, cb):
            conn = sqlite3.connect('chessdb.sqlite')
            cur = conn.cursor()
            surname, name = cb.currentText().split(' ', 1)
            cur.execute("SELECT id FROM player WHERE surname = '{}' AND name = '{}'".format(surname, name))
            ind = cur.fetchone()[0]
            cur.execute("UPDATE {} SET {} = '{}' WHERE id = {}".format('game', 'winner_id', ind, self.id))
            conn.commit()

        self.items.append(self.newComboBox(item['w_surname'] + ' ' + item['w_name'], get_all_players(), winner_changed))
        self.items.append(self.newLabel('Описание:'))

        def descr_changed(le):
            change_one('game', self.id, 'description', le.text())

        self.items.append(self.newLineEdit(item['descr'], descr_changed))

        def delete():
            delete_one('game', self.id)
            self.parent.choose_layout('layout_games')
            self.parent.ui.table_game.clearSelection()

        def show_game():
            self.parent.game = ChessGameWindow(self.id, True)
            self.parent.game.setWindowTitle('Шахматные игры')

        def new_game():
            self.parent.game = ChessGameWindow(self.id, False)
            self.parent.game.setWindowTitle('Шахматные игры')

        self.button_show_game = self.newButton('Посмотреть ход игры', (370, 20), (180, 30), show_game)

        if self.admin:
            self.button_delete = self.newButton('Удалить игру', (370, 100), (180, 30), delete)
            self.button_new_game = self.newButton('Записать ход игры', (370, 60), (180, 30), new_game)

        self.place()

class EditLayoutPlayer(EditLayout):
    def setUi(self):
        self.items = []
        item = get_player_item(self.id)

        self.items.append(self.newLabel('Фамилия:'))

        def surname_changed(le):
            change_one('player', self.id, 'surname', le.text())

        self.items.append(self.newLineEdit(item['surname'], surname_changed))
        self.items.append(self.newLabel('Имя:'))

        def name_changed(le):
            change_one('player', self.id, 'name', le.text())

        self.items.append(self.newLineEdit(item['name'], name_changed))
        self.items.append(self.newLabel('Рейтинг:'))

        def rating_changed(le):
            change_one('player', self.id, 'rating', le.text())

        if not item['rating']:
            item['rating'] = 0
        self.items.append(self.newLineEdit(str(item['rating']), rating_changed, only_numbers = True))
        self.items.append(self.newLabel('Достижения:'))

        def achievements_changed(le):
            change_one('player', self.id, 'achievements', le.text())

        self.items.append(self.newLineEdit(item['achievements'], achievements_changed))

        def team_changed(index, cb):
            conn = sqlite3.connect('chessdb.sqlite')
            cur = conn.cursor()
            name = cb.currentText()
            if name:
                cur.execute("SELECT id FROM team WHERE name = '{}'".format(name))
                ind = cur.fetchone()[0]
                cur.execute("UPDATE {} SET {} = '{}' WHERE id = {}".format('player', 'team_id', ind, self.id))
                conn.commit()
            else:
                cur.execute("UPDATE {} SET {} = ? WHERE id = {}".format('player', 'team_id', self.id), (None, ))
                conn.commit()


        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('SELECT name FROM team')
        all_teams = [i[0] for i in cur.fetchall()]

        self.items.append(self.newLabel('Команда:'))
        self.items.append(self.newComboBox(item['t_name'], [''] + all_teams, team_changed))

        def delete_player():
            delete_one('player', self.id)
            self.parent.choose_layout('layout_players')
            self.parent.ui.table_player.clearSelection()

        if self.admin:
            self.items.append(self.newButton('Удалить игрока', (10,10), (10,10), delete_player))

        self.place()

class EditLayoutOrganizer(EditLayout):
    def setUi(self):
        self.items = []
        item = get_organizer(self.id)

        self.items.append(self.newLabel('Имя:'))

        def name_changed(le):
            change_one('organizer', self.id, 'name', le.text())

        self.items.append(self.newLineEdit(item['name'], name_changed))

        def delete_organizer():
            delete_one('organizer', self.id)
            self.parent.choose_layout('layout_organizers')

        if self.admin:
            self.items.append(self.newButton('Удалить организатора', (10,10), (10,10), delete_organizer))

        self.place()

class MainWindow(QMainWindow):
    def minimize_menu(self):
        self.ui.left_menu.hide()
        self.ui.button_expand.show()

        la = getattr(self.ui, self.current_layout)
        la.move(60, 10)
        la.resize(720, 425)

    def choose_layout(self, layout):
        self.current_layout = layout
        
        for i in dir(self):
            if i.startswith('layout_'):
                getattr(self.ui, i).hide()

        la = getattr(self.ui, layout)

        if layout != 'layout_edit' and 'layout_edit' in dir(self):
            self.ui.layout_edit.setParent(None)
            del self.ui.layout_edit 

        if layout.endswith('games'):
            data, labels = get_data('game')
            self.set_table(self.ui.table_game, labels, data)
            self.set_table(self.ui.table_game, labels, data)

        if layout.endswith('players'):
            data, labels = get_data('player')
            self.set_table(self.ui.table_player, labels, data)
            self.set_table(self.ui.table_player, labels, data)

        if layout.endswith('tournaments'):
            data, labels = get_data('tournament')
            self.set_table(self.ui.table_tournament, labels, data)
            self.set_table(self.ui.table_tournament, labels, data)

        if layout.endswith('organizers'):
            data, labels = get_data('organizer')
            self.set_table(self.ui.table_organizer, labels, data)
            self.set_table(self.ui.table_organizer, labels, data)

        if layout.endswith('places'):
            data, labels = get_data('place')
            self.set_table(self.ui.table_place, labels, data)
            self.set_table(self.ui.table_place, labels, data)

        if layout.endswith('teams'):
            data, labels = get_data('team')
            self.set_table(self.ui.table_team, labels, data)
            self.set_table(self.ui.table_team, labels, data)

        if layout.endswith('best_players'):
            data, labels = get_data('stats')
            self.set_table(self.ui.table_best_players, labels, data)
            self.set_table(self.ui.table_best_players, labels, data)
        
        la.show()
        la.move(230, 10)
        la.resize(550, 425)

    def expand_menu(self):
        self.ui.left_menu.show()
        self.ui.button_expand.hide()

        la = getattr(self.ui, self.current_layout)
        la.move(230, 10)
        la.resize(550, 425)

    def set_table(self, table, labels, data, player = None, tournament = None):
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.itemClicked.connect(self.on_table_click)
        table.setColumnCount(len(labels))
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionMode(QAbstractItemView.SingleSelection)

        table.setHorizontalHeaderLabels(labels)

        table_items = []

        for rows in range(len(data)):
            if player and tournament:
                if data[rows][1]:
                    if (player in data[rows][4] or player in data[rows][5] or player in data[rows][6]) and tournament in data[rows][1]:
                        item = []
                        for cols in range(len(labels)):
                            if data[rows][cols] == None:
                                item.append(QTableWidgetItem(''))
                            else:
                                item.append(QTableWidgetItem(str(data[rows][cols])))
                        table_items.append(item)
            elif player:
                if player in data[rows][4] or player in data[rows][5] or player in data[rows][6]:
                    item = []
                    for cols in range(len(labels)):
                        if data[rows][cols] == None:
                            item.append(QTableWidgetItem(''))
                        else:
                            item.append(QTableWidgetItem(str(data[rows][cols])))
                    table_items.append(item)
            elif tournament:
                if data[rows][1]:
                    if tournament in data[rows][1]:
                        item = []
                        for cols in range(len(labels)):
                            if data[rows][cols] == None:
                                item.append(QTableWidgetItem(''))
                            else:
                                item.append(QTableWidgetItem(str(data[rows][cols])))
                        table_items.append(item)
            else:
                item = []
                for cols in range(len(labels)):
                    if data[rows][cols] == None:
                        item.append(QTableWidgetItem(''))
                    else:
                        item.append(QTableWidgetItem(str(data[rows][cols])))
                table_items.append(item)

        table.setRowCount(len(table_items))

        for rows in range(len(table_items)):
            for cols in range(len(labels)):
                table.setItem(rows, cols, table_items[rows][cols])

        table.resizeColumnsToContents()

    def add_game(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()
        cur.execute('SELECT id FROM player LIMIT 2')
        id1 = cur.fetchone()[0]
        id2 = cur.fetchone()[0]

        cur.execute('SELECT id FROM tournament LIMIT 1')
        tour_id = cur.fetchone()[0]
        cur.execute('''INSERT INTO game (tournament_id, white_player_id, black_player_id, winner_id) 
            VALUES (?, ?, ?, ?)''', (tour_id, id1, id2, id1))
        conn.commit()
        self.ui.layout_edit = EditLayoutGame(self, 'game', cur.lastrowid, self.admin)
        self.ui.table_game.clearSelection()
        self.choose_layout('layout_edit')

    def add_player(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('INSERT INTO player (name, surname) VALUES ("", "")')
        conn.commit()
        self.ui.layout_edit = EditLayoutPlayer(self, 'game', cur.lastrowid, self.admin)
        self.ui.table_player.clearSelection()
        self.choose_layout('layout_edit')

    def add_tournament(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('INSERT INTO tournament (name) VALUES ("")')
        conn.commit()
        self.ui.layout_edit = EditLayoutTournament(self, 'tournament', cur.lastrowid, self.admin)
        self.ui.table_tournament.clearSelection()
        self.choose_layout('layout_edit')

    def add_organizer(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()
        cur.execute('INSERT INTO organizer (name) VALUES ("")')
        conn.commit()
        self.ui.layout_edit = EditLayoutOrganizer(self, 'organizer', cur.lastrowid, self.admin)
        self.ui.table_organizer.clearSelection()
        self.choose_layout('layout_edit')

    def add_place(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()
        cur.execute('INSERT INTO place (adress) VALUES (" ")')
        conn.commit()
        self.ui.layout_edit = EditLayoutPlace(self, 'place', cur.lastrowid, self.admin)
        self.ui.table_place.clearSelection()
        self.choose_layout('layout_edit')

    def add_team(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()
        cur.execute('INSERT INTO team (name) VALUES (" ")')
        conn.commit()
        self.ui.layout_edit = EditLayoutTeam(self, 'team', cur.lastrowid, self.admin)
        self.ui.table_team.clearSelection()
        self.choose_layout('layout_edit')

    def on_table_click(self, item):
        if self.current_layout == 'layout_players':
            self.ui.layout_edit = EditLayoutPlayer(self, 'player', self.ui.table_player.item(item.row(), 0).text(), self.admin)
            self.ui.table_player.clearSelection()
            self.choose_layout('layout_edit')

        if self.current_layout == 'layout_games':
            self.ui.layout_edit = EditLayoutGame(self, 'game', self.ui.table_game.item(item.row(), 0).text(), self.admin)
            self.ui.table_game.clearSelection()
            self.choose_layout('layout_edit')

        if self.current_layout == 'layout_tournaments':
            self.ui.layout_edit = EditLayoutTournament(self, 'tournament', self.ui.table_tournament.item(item.row(), 0).text(), self.admin)
            self.ui.table_tournament.clearSelection()
            self.choose_layout('layout_edit')

        if self.current_layout == 'layout_organizers':
            self.ui.layout_edit = EditLayoutOrganizer(self, 'organizer', self.ui.table_organizer.item(item.row(), 0).text(), self.admin)
            self.ui.table_organizer.clearSelection()
            self.choose_layout('layout_edit')

        if self.current_layout == 'layout_places':
            self.ui.layout_edit = EditLayoutPlace(self, 'place', self.ui.table_place.item(item.row(), 0).text(), self.admin)
            self.ui.table_place.clearSelection()
            self.choose_layout('layout_edit')

        if self.current_layout == 'layout_teams':
            self.ui.layout_edit = EditLayoutTeam(self, 'team', self.ui.table_team.item(item.row(), 0).text(), self.admin)
            self.ui.table_team.clearSelection()
            self.choose_layout('layout_edit')

    def __init__(self, admin = False):
        super().__init__()

        self.ui = uic.loadUi('mainwindow.ui', self)
        self.ui.button_expand.hide()

        self.admin = admin

        self.current_layout = 'layout_tournaments'
        self.choose_layout('layout_tournaments')

        data, labels = get_data('player')
        self.set_table(self.ui.table_player, labels, data)

        data, labels = get_data('game')
        self.set_table(self.ui.table_game, labels, data)

        data, labels = get_data('tournament')
        self.set_table(self.ui.table_tournament, labels, data)

        data, labels = get_data('organizer')
        self.set_table(self.ui.table_organizer, labels, data)

        data, labels = get_data('place')
        self.set_table(self.ui.table_place, labels, data)

        data, labels = get_data('team')
        self.set_table(self.ui.table_team, labels, data)

        if not self.admin:
            self.ui.button_add_game.hide()
            self.ui.button_add_player.hide()
            self.ui.button_add_tournament.hide()
            self.ui.button_add_place.hide()
            self.ui.button_add_team.hide()
            self.ui.button_add_organizer.hide()

        self.ui.button_add_game.clicked.connect(self.add_game)
        self.ui.button_add_player.clicked.connect(self.add_player)
        self.ui.button_add_tournament.clicked.connect(self.add_tournament)
        self.ui.button_add_organizer.clicked.connect(self.add_organizer)
        self.ui.button_add_place.clicked.connect(self.add_place)
        self.ui.button_add_team.clicked.connect(self.add_team)

        def edited_le_find_player():
            data, labels = get_data('game')
            if self.ui.cb_tournament.currentText() != '':
                self.set_table(self.ui.table_game, labels, data, self.ui.le_find_player.text(), 
                    tournament = self.ui.cb_tournament.currentText())
            else:
                self.set_table(self.ui.table_game, labels, data, self.ui.le_find_player.text())


        self.ui.le_find_player.editingFinished.connect(edited_le_find_player)


        def tournament_changed():
            data, labels = get_data('game')
            if self.ui.cb_tournament.currentText() == '':
                 self.set_table(self.ui.table_game, labels, data)
            elif self.ui.le_find_player.text() != '':
                self.set_table(self.ui.table_game, labels, data, self.ui.le_find_player.text(), 
                    tournament = self.ui.cb_tournament.currentText())
            else:
                self.set_table(self.ui.table_game, labels, data, tournament = self.ui.cb_tournament.currentText())

        self.ui.cb_tournament.addItems([''] + get_tournaments_names())
        self.ui.cb_tournament.currentIndexChanged.connect(tournament_changed)

        self.ui.button_minimize.clicked.connect(self.minimize_menu)
        self.ui.button_expand.clicked.connect(self.expand_menu)

        self.ui.games.clicked.connect(partial(self.choose_layout, layout='layout_games'))
        self.ui.players.clicked.connect(partial(self.choose_layout, layout='layout_players'))
        self.ui.tournaments.clicked.connect(partial(self.choose_layout, layout='layout_tournaments'))
        self.ui.organizers.clicked.connect(partial(self.choose_layout, layout='layout_organizers'))
        self.ui.places.clicked.connect(partial(self.choose_layout, layout='layout_places'))
        self.ui.teams.clicked.connect(partial(self.choose_layout, layout='layout_teams'))
        self.ui.best_players.clicked.connect(partial(self.choose_layout, layout='layout_best_players'))

        self.setFixedWidth(self.width())
        self.setFixedHeight(self.height())
        self.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.setWindowTitle('Шахматные игры')
    sys.exit(app.exec_())