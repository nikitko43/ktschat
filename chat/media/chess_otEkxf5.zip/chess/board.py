from PyQt5 import uic
import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QLabel
from PyQt5.QtGui import QPixmap, QDrag
from PyQt5 import QtGui
from PyQt5.QtCore import Qt, QMimeData
from PyQt5 import QtCore
import sqlite3
from time import sleep

convert = {'a': 0, 'b': 1, 'c': 2, 'd': 3, 'e': 4, 'f': 5, 'g': 6, 'h': 7}
convert_inv = {convert[i]: i for i in convert}

def get_square(name = 'a1'):
    position = [27, 13]
    position[0] += convert[name[0]] * 70
    position[1] += ((8 - int(name[1])) * 70)
    return position

def get_name_square(position):
    if type(position) != type([]):
        x = position.x() 
        y = position.y() + 13

    else:
        x = position[0] 
        y = position[1] + 13

    if x//70 not in convert_inv:
        return 

    sq_num = (8*70 - y)//70 + 1 
    if sq_num < 1 or sq_num > 8:
        return

    return str(convert_inv[x // 70]) + str((8*70 - y)//70 + 1)

class Cursor:
    def __init__(self, x, y):
        self._x = x
        self._y = y
    def x(self):
        return self._x
    def y(self):
        return self._y

class Figure(QLabel):
    def __init__(self, parent, pixmap, position, board, notation):
        super().__init__("", parent)
        self.parent = parent
        self.pixmap = pixmap
        self.board = board
        self.notation = notation
        self.square = get_name_square(position)
        self.name = pixmap[1:-4]
        self.moved_at_least_once = False
        self.pawn_doubleturn = -1

        if pixmap[0] == 'w':
        	self.white = True
        else:
        	self.white = False

        self.resize(60, 60)
        self.setAcceptDrops(True)
        self.setPixmap(QPixmap(pixmap))
        self.move(*position)
        self.show()
        self.setAcceptDrops(True)

    def mouseMoveEvent(self, e):
        if e.buttons() != Qt.LeftButton or self.board.game_end:
            return

        currPos = self.mapToGlobal(self.pos())
        globalPos = e.globalPos()
        diff = globalPos - self.__mouseMovePos
        newPos = self.mapFromGlobal(currPos + diff)
        self.move(newPos)

        self.__mouseMovePos = globalPos

    def mousePressEvent(self, e):
        self.__mousePressPos = None
        self.__mouseMovePos = None
        self.__startingPos = None
        if e.button() == QtCore.Qt.LeftButton and not self.board.game_end:
            self.__mousePressPos = e.globalPos()
            self.__mouseMovePos = e.globalPos()
            self.__startingPos = self.pos()

    def mouseReleaseEvent(self, e):
        new_position = self.parent.mapFromGlobal(e.globalPos()) - e.pos()
        if not self.board.game_end:
            self.board.figure_moved(self, new_position, start_position = self.__startingPos)

class BoardLabel(QLabel):
    def __init__(self, parent):
        super().__init__(parent)
        self.setPixmap(QPixmap("board.png"))
        self.move(0, 0)
        self.resize(600, 595)
        self.show() 

class ChessBoard:
    def figure_moved(self, figure, new_position, start_position):
        move = get_name_square(new_position)

        if not move:
            figure.move(start_position)
            return

        square_XY = get_square(move)

        if self.white_turn and figure.white and figure.square != move:
            # проверка на правильность хода
            legal = self.is_move_legal(figure.square, move, figure)
            if not legal:
                figure.move(start_position)
                return

            self.take = '-'    # обычный ход или взятие

            # проверка на взятие фигуры
            check_take = self.figure_on_square(move, white=False)
            if check_take is not None:
                self.take = 'x'
                self.remove_figure_from_square(move)
                check_take.hide()

            # проверка на наличие союзной фигуры
            check = self.figure_on_square(move, white=True)
            if check is not None:
                figure.move(start_position)
                return

            # проверка на promotion пешки в ферзя
            if move[1] == '8' and figure.name == 'pawn':
                figure.hide()
                self.remove_figure_from_square(get_name_square(start_position))
                figure = Figure(self.layout, "wqueen.png", get_square(move), self, 'Ф')
                self.in_game.insert(0, figure)
                legal = (True, 'promotion')

            # запись в нотации
            if type(legal) == type(tuple()):
                if legal[1] == 'e.p.':
                    text = figure.square + 'x' + move + 'e.p.'
                if legal[1] == 'O-O' or legal[1] == 'O-O-O':
                    text = legal[1]
                if legal[1] == 'promotion':
                    text = get_name_square(start_position) + self.take + move + '=Q'
            else:
                text = figure.notation + figure.square + self.take + move

            figure.square = move
            figure.move(*square_XY)

            if check_take:
                if check_take.name == 'king':
                    text += '# 1-0'
                    self.game_end = True 
            else:
                # проверка на шах и мат (королю некуда ходить)
                ckm = self.check_king_mated(False)
                if ckm == '+':
                    text += '+'

            self.textbox.setText(str(self.textbox.toPlainText()) + str(self.turn) + '. ' + text + ' ')
            self.white_turn = False

            figure.moved_at_least_once = True
            if not self.game_end:
                self.parent.save()


        elif not self.white_turn and not figure.white and figure.square != move:
            # проверка на правильность хода
            legal = self.is_move_legal(figure.square, move, figure)
            if not legal:
                figure.move(start_position)
                return

            self.take = '-'  # обычный ход или взятие
            
            # проверка на взятие фигуры
            check_take = self.figure_on_square(move, white=True)
            if check_take is not None:
                self.take = 'x'
                self.remove_figure_from_square(move)
                check_take.hide()

            # проверка на наличие союзной фигуры
            check = self.figure_on_square(move, white=False)
            if check is not None:
                figure.move(start_position)
                return

            # проверка на promotion пешки в ферзя
            if move[1] == '1' and figure.name == 'pawn':
                figure.hide()
                self.remove_figure_from_square(get_name_square(start_position))
                figure = Figure(self.layout, "bqueen.png", get_square(move), self, 'Ф')
                self.in_game.insert(0, figure)
                legal = (True, 'promotion')

            # запись в нотации
            if type(legal) == type(tuple()):
                if legal[1] == 'e.p.':
                    text = figure.square + 'x' + move + 'e.p.'
                if legal[1] == 'O-O' or legal[1] == 'O-O-O':
                    text = legal[1]
                if legal[1] == 'promotion':
                    text = get_name_square(start_position) + self.take + move + '=Q'
            else:
                text = figure.notation + figure.square + self.take + move

            figure.square = move
            figure.move(*square_XY)

            if check_take:
                if check_take.name == 'king':
                    text += '# 0-1'
                    self.game_end = True
            else:
                # проверка на шах и мат (королю некуда ходить)
                ckm = self.check_king_mated(True)
                if ckm == '+':
                    text += '+'

            self.textbox.setText(str(self.textbox.toPlainText()) + ' ' + text + '\n')
            self.turn += 1
            self.white_turn = True

            figure.moved_at_least_once = True
            if not self.game_end:
                self.parent.save()

        else:
            figure.move(start_position)

    # def check_king_mated(self, white = True, position = None):
    #     if white and not position:
    #         position = self.in_game[-1].square
    #     if not white and not position:
    #         position = self.in_game[-2].square

    #     sq_for_check = []
    #     x_range = range(convert[position[0]]-1, convert[position[0]]+2)
    #     y_range = range(int(position[1])-1, int(position[1])+2)
    #     sq_for_check = []
    #     for x in x_range:
    #         for y in y_range:
    #             if x >= 0 and x < 8 and y >= 1 and y <= 8:
    #                 sq_for_check.append(convert_inv[x] + str(y))

    #     checking = {sq: False for sq in sq_for_check}
    #     flatten_in_game = []
    #     attacking = []
    #     _i = [flatten_in_game.append(i) if type(i) != type([]) 
    #           else flatten_in_game.extend(i) for i in self.in_game]

    #     for fig in flatten_in_game:
    #         if white != fig.white:
    #             for sq in checking:
    #                 if not checking[sq]:
    #                     checking[sq] = self.is_move_legal(fig.square, sq, fig)
    #                     if checking[sq] and self.is_move_legal(fig.square, position, fig) and fig not in attacking:
    #                         print('---->', fig.square, position)
    #                         attacking.append(fig)

    #         if white == fig.white and fig.square in checking and fig.name != 'king':
    #             checking[fig.square] = True

    #     if len(attacking) > 0:
    #         check = '+'
    #     else:
    #         check = False

    #     if all(checking.values()) and attacking:
    #         if len(attacking) == 1:
    #             attacking = attacking[0]
    #             print(attacking.square)
    #             print(checking.values())
    #             sq_for_check = self.is_move_legal(attacking.square, position, attacking, True)
    #             for fig in flatten_in_game:
    #                 if (attacking.white != fig.white and self.is_move_legal(fig.square, attacking.square, fig)):
    #                     return '+'

    #                 if white == fig.white:
    #                     for sq in sq_for_check:
    #                         if self.is_move_legal(fig.square, sq, fig):
    #                             return '+'

    #             if self.is_move_legal(self.in_game[-2].square, attacking.square, self.in_game[-2]) and not white:
    #                 return '+'
    #             if self.is_move_legal(self.in_game[-1].square, attacking.square, self.in_game[-1]) and white:
    #                 return '+'

    #         for i in attacking:
    #             print(i.square)

    #         # return 'Мат'

    #     else:
    #         return check

    def check_king_mated(self, white = True, position = None):
        if white and not position:
            position = self.in_game[-1].square
        if not white and not position:
            position = self.in_game[-2].square

        flatten_in_game = []
        _i = [flatten_in_game.append(i) if type(i) != type([]) 
              else flatten_in_game.extend(i) for i in self.in_game]

        for fig in flatten_in_game:
            if white != fig.white:
                if self.is_move_legal(fig.square, position, fig):
                    return '+'

        return False

    def is_move_legal(self, start_pos, move_pos, figure, squares_moving_on = False):
        # ожидаю в start_pos и move_pos названия клеток
        x, y = start_pos
        y = int(y)
        x = convert[x]
        
        x_moved, y_moved = move_pos
        y_moved = int(y_moved)
        x_moved = convert[x_moved] 

        if figure.name == 'pawn' and figure.white:
            check = self.figure_on_square(move_pos, white=False)

            if x == x_moved and y_moved - y == 2 and not figure.moved_at_least_once:
                figure.pawn_doubleturn = self.turn

            conditions = [ x == x_moved and y_moved - y == 2 and not figure.moved_at_least_once,
                           x == x_moved and y_moved - y == 1 and not check,
                           x_moved - x == 1 and y_moved - y == 1 and check,
                           x - x_moved == 1 and y_moved - y == 1 and check
                         ]

            # взятие на проходе
            enpassant = self.figure_on_square(convert_inv[x_moved] + '5', white=False)
            if enpassant and y_moved == 6:
                if enpassant.pawn_doubleturn == self.turn-1:
                    self.remove_figure_from_square(convert_inv[x_moved] + '5')
                    enpassant.hide()
                    return (True, 'e.p.')

            return any(conditions)

        if figure.name == 'pawn' and not figure.white:
            check = self.figure_on_square(move_pos, white=True)
            if x == x_moved and y - y_moved == 2 and not figure.moved_at_least_once:
                figure.pawn_doubleturn = self.turn

            conditions = [ x == x_moved and y - y_moved == 2 and not figure.moved_at_least_once,
                           x == x_moved and y - y_moved == 1 and not check,
                           x_moved - x == 1 and y - y_moved == 1 and check,
                           x - x_moved == 1 and y - y_moved == 1 and check
                         ]

            # взятие на проходе
            enpassant = self.figure_on_square(convert_inv[x_moved] + '4', white=True)
            if enpassant and y_moved == 3:
                if enpassant.pawn_doubleturn == self.turn:
                    self.remove_figure_from_square(convert_inv[x_moved] + '4')
                    enpassant.hide()
                    return (True, 'e.p.')

            return any(conditions)

        def rock(x, y, x_moved, y_moved, squares_moving_on):
            sq_for_check = []
            if x_moved != x and y_moved != y:
                if squares_moving_on:
                    return list()
                return False
            else:
                if x < x_moved:
                    sq_for_check = [convert_inv[i] + str(y) for i in range(x+1, x_moved)]
                if x > x_moved:
                    sq_for_check = [convert_inv[i] + str(y) for i in range(x_moved+1, x)]
                if y < y_moved:
                    sq_for_check = [convert_inv[x] + str(i) for i in range(y+1, y_moved)]
                if y > y_moved:
                    sq_for_check = [convert_inv[x] + str(i) for i in range(y_moved+1, y)]

                if squares_moving_on:
                    return sq_for_check

                for sq in sq_for_check:
                    check = self.figure_on_square(sq, _any = True)
                    if check:
                        return False
                else:
                    return True

        if figure.name == 'rock':
            return rock(x, y, x_moved, y_moved, squares_moving_on)

        if figure.name == 'knight':
            kn = ( (1, 2), (2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1), (-1, 2), (-2, 1) )
            possible_moves = [(x + dx, y + dy) for dx, dy in kn]

            for move in possible_moves:
                mx, my = move
                if mx == x_moved and my == y_moved:
                    if squares_moving_on:
                        return []
                    return True
                
            return False

        def bishop(x, y, x_moved, y_moved, squares_moving_on):
            dx = x_moved - x
            dy = y_moved - y
            if not (abs(dx) == abs(dy)):
                if squares_moving_on:
                    return []
                return False
            else:
                sq_for_check = []
                if dx > 0 and dy > 0:
                    sq_for_check = [convert_inv[x+i] + str(y+i) for i in range(1, x_moved-x)]
                if dx > 0 and dy < 0:
                    sq_for_check = [convert_inv[x+i] + str(y-i) for i in range(1, x_moved-x)]
                if dx < 0 and dy < 0:
                    sq_for_check = [convert_inv[x-i] + str(y-i) for i in range(1, x-x_moved)]
                if dx < 0 and dy > 0:
                    sq_for_check = [convert_inv[x-i] + str(y+i) for i in range(1, x-x_moved)]

                if squares_moving_on:
                    return sq_for_check

                for sq in sq_for_check:
                    check = self.figure_on_square(sq, _any = True)
                    if check:
                        return False
                else:
                    return True

        if figure.name == 'bishop':
            return bishop(x, y, x_moved, y_moved, squares_moving_on)

        if figure.name == 'queen':
            if squares_moving_on:
                added = rock(x, y, x_moved, y_moved, True)
                for i in bishop(x, y, x_moved, y_moved, True):
                    added.append(i)
                return added
            return rock(x, y, x_moved, y_moved, False) or bishop(x, y, x_moved, y_moved, False)

        if figure.name == 'king':
            dx = x_moved - x
            dy = y_moved - y

            # большая проверка на рокировку
            check_for_castling1 = self.figure_on_square('h1', white=True)
            check_for_castling2 = self.figure_on_square('a1', white=True)
            if figure.white and check_for_castling1:
                if (x_moved == 6 and y_moved == 1 and not figure.moved_at_least_once 
                    and not check_for_castling1.moved_at_least_once):
                    check_for_castling1.square = 'f1'
                    check_for_castling1.move(*get_square('f1'))
                    return (True, 'O-O')

            if figure.white and check_for_castling2:
                if (x_moved == 2 and y_moved == 1 and not figure.moved_at_least_once 
                    and not check_for_castling2.moved_at_least_once):
                    check_for_castling2.square = 'd1'
                    check_for_castling2.move(*get_square('d1'))
                    return (True, 'O-O-O')

            check_for_castling1 = self.figure_on_square('h8', white=False)
            check_for_castling2 = self.figure_on_square('a8', white=False)
            if not figure.white and check_for_castling1:
                if (x_moved == 6 and y_moved == 8 and not figure.moved_at_least_once 
                    and not check_for_castling1.moved_at_least_once):
                    check_for_castling1.square = 'f8'
                    check_for_castling1.move(*get_square('f8'))
                    return (True, 'O-O')

            if not figure.white and check_for_castling2:
                if (x_moved == 2 and y_moved == 8 and not figure.moved_at_least_once 
                    and not check_for_castling2.moved_at_least_once):
                    check_for_castling1.square = 'd8'
                    check_for_castling2.move(*get_square('d8'))
                    return (True, 'O-O-O')
            # ----------


            return (abs(dx) <= 1 and abs(dy) <= 1)


    def figure_on_square(self, position, white = False, _any=False):
        for fig in self.in_game:
            if type(fig) == type([]):
                for f in fig:
                    if f.square == position and ((white == f.white) or _any):
                        return f
            else:
                if fig.square == position and ((white == fig.white) or _any):
                    return fig
        return None

    def remove_figure_from_square(self, position):
        for fig in self.in_game:
            if type(fig) == type([]):
                for f in fig:
                    if f.square == position:
                        fig.remove(f)
            else:
                if fig.square == position:
                    self.in_game.remove(fig)


    def __init__(self, layout, textbox, parent):
        self.white_turn = True
        self.game_end = False
        self.layout = layout
        self.turn = 1
        self.parent = parent

        self.textbox = textbox

        self.bpawn = []
        self.wpawn = []

        for sq in ('a','b','c','d','e','f','g','h'):
            self.bpawn.append(Figure(layout, "bpawn.png", get_square(sq+'7'), self, ''))
            self.wpawn.append(Figure(layout, "wpawn.png", get_square(sq+'2'), self, ''))

        self.bbishop = []
        self.bbishop.append(Figure(layout, "bbishop.png", get_square('c8'), self, 'С'))
        self.bbishop.append(Figure(layout, "bbishop.png", get_square('f8'), self, 'С'))

        self.wbishop = []
        self.wbishop.append(Figure(layout, "wbishop.png", get_square('c1'), self, 'С'))
        self.wbishop.append(Figure(layout, "wbishop.png", get_square('f1'), self, 'С'))

        self.brock = []
        self.brock.append(Figure(layout, "brock.png", get_square('a8'), self, 'Л'))
        self.brock.append(Figure(layout, "brock.png", get_square('h8'), self, 'Л'))

        self.wrock = []
        self.wrock.append(Figure(layout, "wrock.png", get_square('a1'), self, 'Л'))
        self.wrock.append(Figure(layout, "wrock.png", get_square('h1'), self, 'Л'))

        self.bknight = []
        self.bknight.append(Figure(layout, "bknight.png", get_square('b8'), self, 'К'))
        self.bknight.append(Figure(layout, "bknight.png", get_square('g8'), self, 'К'))

        self.wknight = []
        self.wknight.append(Figure(layout, "wknight.png", get_square('b1'), self, 'К'))
        self.wknight.append(Figure(layout, "wknight.png", get_square('g1'), self, 'К'))

        self.bqueen = Figure(layout, "bqueen.png", get_square('d8'), self, 'Ф')
        self.wqueen = Figure(layout, "wqueen.png", get_square('d1'), self, 'Ф')
        self.bking = Figure(layout, "bking.png", get_square('e8'), self, 'Кр')
        self.wking = Figure(layout, "wking.png", get_square('e1'), self, 'Кр')

        self.in_game = [self.bpawn, self.wpawn, self.bbishop, self.wbishop, 
                    self.brock, self.wrock, self.bknight, self.wknight,
                    self.bqueen, self.wqueen, self.bking, self.wking]


class ChessGameWindow(QMainWindow):
    def __init__(self, _id, is_show = True):
        super().__init__()

        self.ui = uic.loadUi('board.ui', self)
        self.is_show = is_show
        self.board_label = BoardLabel(self)
        self.id = _id
        self.ui.text_box.setReadOnly(True)
        self.board = ChessBoard(self.board_label, self.ui.text_box, self)

        if not is_show:
            self.ui.button_left.hide()
            self.ui.button_right.hide()
            self.ui.button_left_2.hide()
            self.ui.button_right_2.hide()
            self.ui.clear_button.clicked.connect(self.clear)
            self.ui.save_button.clicked.connect(self.save)
            self.ui.draw_button.clicked.connect(self.draw)
            self.ui.white_button.clicked.connect(self.white)
            self.ui.black_button.clicked.connect(self.black)

        if is_show:
            for b in ['clear_button', 'save_button', 'draw_button', 'white_button', 'black_button']:
                getattr(self.ui, b).hide()

            conn = sqlite3.connect('chessdb.sqlite')
            cur = conn.cursor()

            text = ''
            self.moves = {}
            self.current_move = 1
            self.current_move_white = True
            self.ui.button_left.clicked.connect(self.prev_turn)
            self.ui.button_right.clicked.connect(self.next_turn)
            self.ui.button_left_2.clicked.connect(self.restart)
            self.ui.button_right_2.clicked.connect(self.to_end)
            self.ui.button_left.clearFocus()

            cur.execute('SELECT * FROM move WHERE game_id = ?', (self.id, ))
            for i in cur.fetchall():
                move = self.get_move_from_db(i)
                if move:
                    self.moves[move['num']] = move

            if not self.moves:
                self.moves = {1:{'game_end': 'white'}}

            self.board.game_end = True
            self.text_box.setText(text)

        self.show()

    def to_end(self):
        while not self.next_turn():
            pass

    def restart(self):
        self.board_label = BoardLabel(self)
        self.board = ChessBoard(self.board_label, self.ui.text_box, self)
        self.current_move = 1
        self.current_move_white = True
        self.ui.text_box.setText('')

    def prev_turn(self):
        if self.current_move == 1 and self.current_move_white:
            return

        if self.current_move_white:
            needed_turn = self.current_move - 1
            needed_white = False
        else:
            needed_turn = self.current_move
            needed_white = True

        self.restart()

        while self.current_move != needed_turn or needed_white != self.current_move_white:
            self.next_turn()

    def next_turn(self):
        cur = self.current_move
        white = self.current_move_white
        b = self.board

        if self.current_move > max(list(self.moves.keys())):
            return True

        if self.moves[1]['game_end']:
            return True

        if not white and self.moves[cur]['game_end'] == 'white':
            return True

        if self.current_move_white:
            if self.moves[cur]['from_white'] == 'O-O':
                self.moves[cur]['from_white'] = 'e1'
                self.moves[cur]['white_take'] = '-'
                self.moves[cur]['to_white'] = 'g1'

            elif self.moves[cur]['from_white'] == 'O-O-O':
                self.moves[cur]['from_white'] = 'e1'
                self.moves[cur]['white_take'] = '-'
                self.moves[cur]['to_white'] = 'c1'

            x, y = get_square(self.moves[cur]['from_white'])
            x, y = x + 10, y + 10
            from_m = Cursor(x, y)
            x, y = get_square(self.moves[cur]['to_white'])
            x, y = x + 10, y + 10
            to_m = Cursor(x, y)
            self.board.figure_moved(b.figure_on_square(self.moves[cur]['from_white'], _any = True), to_m, from_m)
            self.current_move_white = False

        else:
            if self.moves[cur]['from_black'] == 'O-O':
                self.moves[cur]['from_black'] = 'e8'
                self.moves[cur]['black_take'] = '-'
                self.moves[cur]['to_black'] = 'g8'

            elif self.moves[cur]['from_black'] == 'O-O-O':
                self.moves[cur]['from_black'] = 'e8'
                self.moves[cur]['black_take'] = '-'
                self.moves[cur]['to_black'] = 'c8'
            x, y = get_square(self.moves[cur]['from_black'])
            x, y = x + 10, y + 10
            from_m = Cursor(x, y)
            x, y = get_square(self.moves[cur]['to_black'])
            x, y = x + 10, y + 10
            to_m = Cursor(x, y)
            self.board.figure_moved(b.figure_on_square(self.moves[cur]['from_black'], _any = True), to_m, from_m)
            self.current_move_white = True
            self.current_move += 1

    def get_move_from_db(self, move):
        turn = {}
        turn['num'] = move[1]
        ge = True
        if not move[3]:
            turn['game_end'] = 'white'
            ge = False
        elif move[3] == '½—½' or move[3] == '1-0' or move[3] == '0-1':
            turn['game_end'] = 'white'
        elif move[4] and move[3]:
            turn['game_end'] = 'black'
        else:
            turn['game_end'] = ''

        wh_move = move[2]
        if wh_move.endswith('=Q'):
            turn['white_promotion'] = 'promotion'
        if move[2].startswith(('Л', 'К', 'Ф', 'С')):
            wh_move = move[2][1:]
        if move[2].startswith('Кр'):
            wh_move = move[2][2:]
        turn['from_white'] = wh_move[:2]
        turn['white_take'] = wh_move[2]
        turn['to_white'] = wh_move[3:5]
        if len(wh_move) == 9:
            turn['white_take'] = 'e.p.'

        if ge:
            bl_move = move[3]

            if bl_move.endswith('=Q'):
                turn['black_promotion'] = 'promotion'
            if move[3].startswith(('Л', 'К', 'Ф', 'С')):
                bl_move = move[3][1:]
            if move[3].startswith('Кр'):
                bl_move = move[3][2:]
            turn['from_black'] = bl_move[:2]
            turn['black_take'] = bl_move[2]
            turn['to_black'] = bl_move[3:5]
            if len(bl_move) == 9:
                turn['black_take'] = 'e.p.'

        if move[2] == 'O-O':
            turn['from_white'] = 'O-O'

        elif move[2] == 'O-O-O':
            turn['from_white'] = 'O-O-O'

        if move[3] == 'O-O':
            turn['from_black'] = 'O-O'

        elif move[3] == 'O-O-O':
            turn['from_black'] = 'O-O-O'

        return turn

    def draw(self):
        self.board.game_end = True
        if self.text_box.toPlainText()[-1] == '\n':
            self.text_box.setText(str(self.text_box.toPlainText())[:-1] + ' ½—½')
        else:
            self.text_box.setText(str(self.text_box.toPlainText()) + '½—½')

    def clear(self):
        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('DELETE FROM move where game_id = ?', (self.id,))
        conn.commit()
        self.board_label.setParent(None)
        self.board_label = BoardLabel(self)
        self.board = ChessBoard(self.board_label, self.ui.text_box, self)
        self.ui.text_box.clear()

    def white(self):
        self.board.game_end = True
        if self.text_box.toPlainText()[-1] == '\n':
            self.text_box.setText(str(self.text_box.toPlainText())[:-1]+ ' 1-0')
        else:
            self.text_box.setText(str(self.text_box.toPlainText()) + '1-0')

    def black(self):
        self.board.game_end = True
        if self.text_box.toPlainText()[-1] == '\n':
            self.text_box.setText(str(self.text_box.toPlainText())[:-1] + ' 0-1')
        else:
            self.text_box.setText(str(self.text_box.toPlainText()) + '0-1')

    def save(self):
        text = self.ui.text_box.toPlainText().split('\n')

        turns = []
        for i in text:
            appending = list(i.split())
            if len(appending) == 2:
                appending.append('')
            if appending == []:
                break
            if len(appending) != 4:
                if appending[2] == '1-0' or appending[2] == '0-1' or appending[2] == '½—½':
                    appending.append(appending[2])
                else:
                    appending.append('')
            turns.append(appending)

        if turns[-1] == []:
            turns.pop(len(turns)-1)

        conn = sqlite3.connect('chessdb.sqlite')
        cur = conn.cursor()

        cur.execute('DELETE FROM move where game_id = ?', (self.id,))
        conn.commit()

        for turn in turns:
            cur.execute('INSERT INTO move (order_number, white_move, black_move, game_end, game_id) VALUES (?,?,?,?,?)', turn + [self.id,])

        conn.commit()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    game_id = 1
    window = ChessGameWindow(game_id, True)
    window.setWindowTitle('Шахматные игры')
    sys.exit(app.exec_())